import pickle
mylist=[1,2,3,4]
ser=pickle.dumps(mylist)
print(ser)